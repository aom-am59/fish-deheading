#draw straight line from two double click point
# Draw a diagonal blue line with thickness of 5 px
#img = cv2.line(img,(x,y),(0,0),(255,0,0),5)

import numpy as np
import cv2
img = cv2.imread('Image1.png',1)

# Draw a diagonal blue line with thickness of 5 px
img = cv2.line(img,(742,853),(582,839),(255,0,0),5)
cv2.imshow('tuna',img)
k = cv2.waitKey(0)