import numpy as np
import cv2

img = cv2.imread('index.jpeg',1)
img = cv2.ellipse(img,(256,256),(100,50),0,0,180,255,-1)
cv2.imshow('tuna',img)

k = cv2.waitKey(0)
if k == 27:         # wait for ESC key to exit
	cv2.destroyAllWindows()
elif k == ord('s'): # wait for 's' key to save and exit
	cv2.imwrite('messigray.png',img)
	cv2.destroyAllWindows()
